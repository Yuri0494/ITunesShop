import SearchResultPanel from './cards.js'
export default SearchResultPanel
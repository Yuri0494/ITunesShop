import ITunesCard from './newCard.js';
export default ITunesCard;
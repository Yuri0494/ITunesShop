import CardsList from './search-result-list.js'
export default CardsList;
import SearchPanel from './searchPanel';
export default SearchPanel;
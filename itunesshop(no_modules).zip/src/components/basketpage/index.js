import BasketPage from "./basketpage.js"
export default BasketPage
import Footer from "./footer"
export default Footer
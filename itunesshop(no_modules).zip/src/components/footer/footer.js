import React from "react"
import './footer.css';

function Footer () {
    return (
        <div className="footer"><p>All rights reserved © 2021</p></div>
    )

}  

export default Footer